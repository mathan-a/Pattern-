//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import screen_capturer

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  ScreenCapturerPlugin.register(with: registry.registrar(forPlugin: "ScreenCapturerPlugin"))
}
