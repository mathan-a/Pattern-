package com.example.untitled
import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity
import io.flutter.plugin.common.MethodChannel
class MainActivity: FlutterActivity() {
    private val CHANNEL = "record_channel"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        MethodChannel(flutterEngine!!.dartExecutor.binaryMessenger, CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "startRecording" -> {
                        // Implement logic to start recording
                        result.success(null)
                    }
                    "stopRecording" -> {
                        // Implement logic to stop recording
                        result.success(null)
                    }
                    else -> {
                        result.notImplemented()
                    }
                }
            }

    }
}
